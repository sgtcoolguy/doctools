1. To test SampleIllegal-InputCustomProtocol.txt
use the converter.testcustom.properties from this directory
