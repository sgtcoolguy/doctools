#!/bin/bash

echo "CustomProto"
./compare.sh CustomProto

