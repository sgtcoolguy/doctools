#!/bin/bash

echo "1"
./compare.sh 1

echo "2"
./compare.sh 2

echo "3"
./compare.sh 3

echo "4"
./compare.sh 4

echo "5"
./compare.sh 5

echo "6"
./compare.sh 6

echo "7"
./compare.sh 7

echo "8"
./compare.sh 8

echo "9"
./compare.sh 9

echo "10"
./compare.sh 10

echo "11"
./compare.sh 11

