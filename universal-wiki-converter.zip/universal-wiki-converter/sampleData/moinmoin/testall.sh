#!/bin/bash

echo "1"
./compare.sh 1

echo "2"
./compare.sh 2

echo "3"
./compare.sh 3

echo "AltAtt"
./compare.sh AltAtt 

echo "RelativeLinking"
./compare.sh RelativeLinking
