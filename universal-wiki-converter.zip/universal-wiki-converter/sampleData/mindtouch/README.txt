1. Testing comments
* Run the mindtouch converter on
** 1_SampleMindtouch_InputComments.xml
* and upload to confluence.
* Examine:
** 1_SampleMindtouch_InputComments
* It should have comments attached.

2. Testing tags
* Run the mindtouch converter on
** 1_SampleMindtouch_InputTags.xml
* and upload to confluence.
* Examine:
** 1_SampleMindtouch_InputTags
* It should have tags attached.

3. Testing attachments
* Run the mindtouch converter on
** 40_SampleMindtouch_InputAttachments.xml
* and upload to confluence.
* Examine:
** 40_SampleMindtouch_InputAttachments
* It should have >= 3 files attached, and the inline and links should properly render.

