#!/bin/bash

echo "Basic"
./compare.sh Basic

echo "NoText"
./compare.sh NoText 

echo "Blog"
./compare.sh Blog

echo "BlogPersonal"
./compare.sh BlogPersonal

echo "Quote"
./compare.sh Quote

echo "Toc"
./compare.sh Toc

echo "Link"
./compare.sh Link

echo "Tag"
./compare.sh Tag

echo "ExcludeTag"
./compare.sh ExcludeTag

echo "Att"
./compare.sh Att

echo "Brace"
./compare.sh Brace

echo "Pre"
./compare.sh Pre

echo "Table"
./compare.sh Table
