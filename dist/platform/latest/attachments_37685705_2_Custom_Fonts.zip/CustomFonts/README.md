This project demonstrates how to use custom fonts in your Titanium application. For more information, see [Custom Fonts](http://docs.appcelerator.com/titanium/latest/#!/guide/Custom_Fonts).


----------------------------------
Stuff our legal folk make us say:

Appcelerator, Appcelerator Titanium and associated marks and logos are 
trademarks of Appcelerator, Inc. 

Titanium is Copyright (c) 2008-2013 by Appcelerator, Inc. All Rights Reserved.

Titanium is licensed under the Apache Public License (Version 2). Please
see the LICENSE file for the full license.

